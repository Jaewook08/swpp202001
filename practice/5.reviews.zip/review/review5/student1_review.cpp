#include "llvm/IR/PassManager.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include <map>

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

/* My general comment on this code is that although the code works for most
 * test cases (it did not pass some of my custom tests), it generally does not
 * abide by coding conventions, naming conventions (CamelCase), and the general
 * notion of clean code structure. Furthermore, certain parts of the code are 
 * inefficient and hence introduce unnecessary memory usage and extra loop 
 * iterations. More specific comments are left along with the code */
namespace
{
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality>
{

public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM)
  {

    vector<pair<Value *, Value *>> equality; //will convert second to first
    vector<BasicBlockEdge> checkBlock;       //Branchblock-Trueblock edge

    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    /* There is really no need to create separate vecor for function arguments.
     * Rather, you can simply apply dyn_cast<Argument>(Value), and check if it
     * returns non-NULL value. If so, you can safely assume that it is a
     * function argument. You can then use getArgNo() to get argument order */
    vector<Value *> args; //function arguments

    for (Argument &Arg : F.args())
    {
      args.push_back(&Arg);
    }

    //check for br (icmp eq X Y) Tb Fb
    for (auto &BB : F)
    {
      for (auto &I : BB)
      {
        ICmpInst::Predicate Pred;
        BasicBlock *Tb, *Fb; //Trueblock, Falseblock
        Value *X, *Y; // Eqaulity values

        if (match(&I, m_Br(m_ICmp(Pred, m_Value(X), m_Value(Y)),m_BasicBlock(Tb), m_BasicBlock(Fb))) 
            &&Pred == ICmpInst::ICMP_EQ)
        { //match inst

          //check if value is undef
          auto xundef = dyn_cast<UndefValue>(X);
          auto yundef = dyn_cast<UndefValue>(Y);

          /* Setting the condition as (!X) would more follow coding 
           * conventions rather than (X != nullptr) */
          if (xundef != nullptr || yundef != nullptr)
            continue; //if at least one is undef, don't make any changes

          bool isInverted = false; //true if X should be changed to Y

          //check if X or Y is arg
          auto xargpos = find(args.begin(), args.end(), X);
          auto yargpos = find(args.begin(), args.end(), Y);

          isInverted = (xargpos > yargpos); //check which argument comes first

          if (xargpos == args.end() && yargpos == args.end())
          { //if both are inst
            Instruction *xinst, *yinst; //cast as instruction for checking dominance
            xinst = dyn_cast<Instruction>(X);
            yinst = dyn_cast<Instruction>(Y);
            if (xinst != nullptr && yinst != nullptr)
            {
              //if y dominates x, invert order
              isInverted = (!DT.dominates(xinst, yinst)) && (DT.dominates(yinst, xinst));
            }
          }

          equality.push_back((!isInverted) ? pair(X, Y) : pair(Y, X));

          BasicBlockEdge bbe(&BB, Tb);
          checkBlock.push_back(bbe);
        }
      }
    }

    //check for use of Y
    unsigned int unchangedcount = 0;  //count how many sequential no changes occured

    /* Again, using while loop here is unnecessary. First of all, there is 
     * a vector created dedicated for this loop. Hence, you can simply use
     * for-each syntax to iterate through each equality cases; using while
     * loop and separately declaring another variables (findvalue, replaceto)
     * just to retrieve vector elements in order is redundant and unnecessary.
     * Second, the rationale behind usage of unchangedcount is really
     * ambiguous. If each iteration of this while loop goes through every 
     * instruction within the given IR code, what is the point of keeping the
     * loop going until every element in vector sequentially cause no change?
     * Again, this can be all simplified by looping through each element in
     * vector equality. Erasing and pushing back every element seems
     * inefficient. */
    while (unchangedcount < equality.size()) //will exit when no changes are made for every (X,Y) pair
    {
      Value *findvalue = equality[0].second; //Y
      Value *replaceto = equality[0].first;  //X

      BasicBlockEdge bbe = checkBlock[0]; //Branchblock-Trueblock edge

      bool changed = false; //did anything change?

      /* Iterating through every instruction within given IR program just to
       * locate usages of already known instruction is unnecessary, and will
       * slow down optimization for large input codes. You can simply iterate
       * through just the usages of given instruction by creating a for loop
       * with use_begin() and use_end() */
      for (auto &BB : F)
      {
        for (auto &I : BB)
        {
          for (unsigned int i = 0; i < I.getNumOperands(); i++)
          {
            auto *op = I.getOperand(i);
            if (op == findvalue)
            {
              /* Important: This code will not work in cases where the
               * equality condition partially dominates a basic block. More
               * specifically, this will not work in certain cases of phi
               * instruction usage. For example, if there are basic blocks
               * A and B, both branch to basic block C, C uses phi
               * instruction as phi [x, A], [x, B], and only in block A
               * x == z holds, the instruction must be optimized to
               * phi [z, A], [x, B]. However, this code will not work for
               * such case. To make it work, dominates() must be called with
               * Use or Value, rather than the whole basic block */
              if (DT.dominates(bbe, &BB))
              {
                I.setOperand(i, replaceto); //change Y->X
                changed = true;
              }
            }
          }
        }
      }
      
      //move current items to the back of the vector
      equality.erase(equality.begin());
      checkBlock.erase(checkBlock.begin());
      equality.push_back(pair(replaceto, findvalue));
      checkBlock.push_back(bbe);
      
      if (changed)
        unchangedcount = 0;
      else
        unchangedcount++;
    }

    return PreservedAnalyses::all();
  }
};
} // namespace

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo()
{
  return {
      LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
      [](PassBuilder &PB) {
        PB.registerPipelineParsingCallback(
            [](StringRef Name, FunctionPassManager &FPM,
               ArrayRef<PassBuilder::PipelineElement>) {
              if (Name == "prop-int-eq")
              {
                FPM.addPass(PropagateIntegerEquality());
                return true;
              }
              return false;
            });
      }};
}
