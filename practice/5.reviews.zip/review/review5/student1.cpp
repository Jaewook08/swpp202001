#include "llvm/IR/PassManager.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include <map>

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace
{
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality>
{

public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM)
  {

    vector<pair<Value *, Value *>> equality; //will convert second to first
    vector<BasicBlockEdge> checkBlock;       //Branchblock-Trueblock edge

    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    vector<Value *> args; //function arguments

    for (Argument &Arg : F.args())
    {
      args.push_back(&Arg);
    }

    //check for br (icmp eq X Y) Tb Fb
    for (auto &BB : F)
    {
      for (auto &I : BB)
      {
        ICmpInst::Predicate Pred;
        BasicBlock *Tb, *Fb; //Trueblock, Falseblock
        Value *X, *Y; // Eqaulity values

        if (match(&I, m_Br(m_ICmp(Pred, m_Value(X), m_Value(Y)),m_BasicBlock(Tb), m_BasicBlock(Fb))) 
            &&Pred == ICmpInst::ICMP_EQ)
        { //match inst

          //check if value is undef
          auto xundef = dyn_cast<UndefValue>(X);
          auto yundef = dyn_cast<UndefValue>(Y);

          if (xundef != nullptr || yundef != nullptr)
            continue; //if at least one is undef, don't make any changes

          bool isInverted = false; //true if X should be changed to Y

          //check if X or Y is arg
          auto xargpos = find(args.begin(), args.end(), X);
          auto yargpos = find(args.begin(), args.end(), Y);

          isInverted = (xargpos > yargpos); //check which argument comes first

          if (xargpos == args.end() && yargpos == args.end())
          { //if both are inst
            Instruction *xinst, *yinst; //cast as instruction for checking dominance
            xinst = dyn_cast<Instruction>(X);
            yinst = dyn_cast<Instruction>(Y);
            if (xinst != nullptr && yinst != nullptr)
            {
              //if y dominates x, invert order
              isInverted = (!DT.dominates(xinst, yinst)) && (DT.dominates(yinst, xinst));
            }
          }

          equality.push_back((!isInverted) ? pair(X, Y) : pair(Y, X));

          BasicBlockEdge bbe(&BB, Tb);
          checkBlock.push_back(bbe);
        }
      }
    }

    //check for use of Y
    unsigned int unchangedcount = 0;  //count how many sequential no changes occured

    while (unchangedcount < equality.size()) //will exit when no changes are made for every (X,Y) pair
    {
      Value *findvalue = equality[0].second; //Y
      Value *replaceto = equality[0].first;  //X

      BasicBlockEdge bbe = checkBlock[0]; //Branchblock-Trueblock edge

      bool changed = false; //did anything change?

      for (auto &BB : F)
      {
        for (auto &I : BB)
        {
          for (unsigned int i = 0; i < I.getNumOperands(); i++)
          {
            auto *op = I.getOperand(i);
            if (op == findvalue)
            {
              if (DT.dominates(bbe, &BB))
              {
                I.setOperand(i, replaceto); //change Y->X
                changed = true;
              }
            }
          }
        }
      }
      
      //move current items to the back of the vector
      equality.erase(equality.begin());
      checkBlock.erase(checkBlock.begin());
      equality.push_back(pair(replaceto, findvalue));
      checkBlock.push_back(bbe);
      
      if (changed)
        unchangedcount = 0;
      else
        unchangedcount++;
    }

    return PreservedAnalyses::all();
  }
};
} // namespace

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo()
{
  return {
      LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
      [](PassBuilder &PB) {
        PB.registerPipelineParsingCallback(
            [](StringRef Name, FunctionPassManager &FPM,
               ArrayRef<PassBuilder::PipelineElement>) {
              if (Name == "prop-int-eq")
              {
                FPM.addPass(PropagateIntegerEquality());
                return true;
              }
              return false;
            });
      }};
}
