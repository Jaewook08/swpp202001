#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include<vector>
#include "llvm/IR/PatternMatch.h"

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
	class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {
		public:
			PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
				DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

				vector<StringRef> arg;

				for (Argument &Arg : F.args()) {
					arg.push_back(Arg.getName());
				}

				for (auto &BBEntry : F) {
					BranchInst *TI = dyn_cast<BranchInst>(BBEntry.getTerminator());
					if (!TI) {
					}
					else {
						for (auto &I : BBEntry) {
							Value *X, *Y;
							ConstantInt *C;
							ICmpInst::Predicate Pred;
							
							arg.push_back(I.getName());

							if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) && Pred == ICmpInst::ICMP_EQ) {
								BasicBlock *BBNext = TI->getSuccessor(0);
								BasicBlockEdge BBE(&BBEntry, BBNext);

								Value *V1 = I.getOperand(0);
								Value *V2 = I.getOperand(1);

								int vOrder1 = -1;
								int vOrder2 = -1;
								if(find(arg.begin(), arg.end(), V1->getName()) != arg.end())
									vOrder1 = distance(arg.begin(), find(arg.begin(), arg.end(), V1->getName()));
								if(find(arg.begin(), arg.end(), V2->getName()) != arg.end())
									vOrder2 = distance(arg.begin(), find(arg.begin(), arg.end(), V2->getName()));		
								if (vOrder1 == -1) {
									arg.push_back(V1->getName());
									vOrder1 = vOrder2 + 1;
								}
								if (vOrder2 == -1) {
									arg.push_back(V2->getName());
									vOrder2 = vOrder1 + 1;
								}
								
								if (vOrder1 < vOrder2) {
									for (Use &U : Y->uses()){
										for (Use &U : Y->uses()) {
											User *Usr = U.getUser();
											Instruction *UsrI = dyn_cast<Instruction>(Usr);
											if (UsrI) {
												BasicBlock *BBParent = UsrI->getParent();
												if (DT.dominates(BBE, BBParent))
													if (U != X) {
														U.set(X);
													}
											}
										}
									}
								}
								else {
									for (Use &U : X->uses()) {
										for (Use &U : X->uses()) {
											User *Usr = U.getUser();
											Instruction *UsrI = dyn_cast<Instruction>(Usr);
											if (UsrI) {
												BasicBlock *BBParent = UsrI->getParent();
												if (DT.dominates(BBE, BBParent))
													if (U != Y) {
														U.set(Y);
													}
											}
										}
									}
								}
							}
						}
					}
				}
				return PreservedAnalyses::all();
			}
	};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
	return {
		LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
			[](PassBuilder &PB) {
				PB.registerPipelineParsingCallback(
						[](StringRef Name, FunctionPassManager &FPM,
							ArrayRef<PassBuilder::PipelineElement>) {
						if (Name == "prop-int-eq") {
						FPM.addPass(PropagateIntegerEquality());
						return true;
						}
						return false;
						}
						);
			}
	};
}





