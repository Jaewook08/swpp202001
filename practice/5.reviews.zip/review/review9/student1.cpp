#include "llvm/IR/PassManager.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"

#include <map>
#include <set>
#include <queue>

#define STD_HAS_ELEMENT(M, X) ((M).find(X) != (M).end())

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;


namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {

private:
  typedef pair<Value*,Value*> replacement;         // (A, B) means replace A <- B
  typedef pair<BasicBlock*,BasicBlock*> blockEdge; // (BX, BY) means a directional edge (BX, BY)
                                                   // BasicBlockEdge is not good for map indexing

  // getReplacementOrder - determines whether (X <- Y) or (Y <- X) is valid.
  // Return value 0 means the replacement X <- Y is valid
  // Return value 1 means the replacement Y <- X is valid
  // Return value -1 means the replacement is not valid
  int getReplacementOrder(
    Value *X, Value *Y, map<BasicBlock*,map<Value*,int>> &instOrder,
    DominatorTree &DT
  ) {
    Argument *AX = dyn_cast<Argument>(X);
    Argument *AY = dyn_cast<Argument>(Y);
    Instruction *IX = dyn_cast<Instruction>(X);
    Instruction *IY = dyn_cast<Instruction>(Y);

    // Neither Arg nor Instr. (Maybe Const?)
    if (!(AX || IX) || !(AY || IY)) return -1;

    // If a dominator block contains `C = icmp eq T X, Y',
    if (IX) {
      if (IY) {
        // If X is Instr and Y is Instr, then
        BasicBlock *BX = IX->getParent(), *BY = IY->getParent();

        // If BX == BY, then consider instOrder
        if (BX == BY) return instOrder[BX][X] < instOrder[BY][Y];
        else if (DT.dominates(BX, BY)) return 1; // If BX dominates BY, then Y <- X
        else if (DT.dominates(BY, BX)) return 0; // If BY dominates BX, then X <- Y
        else return -1;  // Not replacable
      } else {
        return 0; // If X is Instr and Y is Arg, then X <- Y
      }
    } else {
      if (IY) {
        return 1; // If X is Arg and Y is Instr == 0, then Y <- X
      } else {
        // If 0 < X's ArgNo < Y's ArgNo, then Y <- X
        // If 0 < Y's ArgNo < X's ArgNo, then X <- Y
        return AX->getArgNo() < AY->getArgNo();
      }
    }
  }

  // getDominationOrder - To make a safe order of BasicBlockEdge to propagate replacements.
  // Note that; typedef pair<BasicBlock*,BasicBlock*> blockEdge
  vector<blockEdge>* getDominationOrder(
    DominatorTree &DT,
    map<BasicBlock*,set<BasicBlock*>> &edges
  ) {
    vector<blockEdge> *edge_order = new vector<blockEdge>(); // Return vector

    vector<blockEdge> all_edges; // Collect all edges with type
    for (auto &[X, SY] : edges) {
      for (auto &Y : SY) {
        all_edges.emplace_back(X, Y);
      }
    }
    
    // Eliminate every edge in the dominance ordering.
    int num_edges = all_edges.size(), num_not_elim = num_edges;
    vector<bool> elim(num_edges, 0), dominated(num_edges);

    // Worst case O(n^3) running time; Too slow. I want to improve further
    while (num_not_elim > 0) {
      fill(dominated.begin(), dominated.end(), 0);
      for (int i=0; i<num_edges; i++) {
        if (elim[i]) continue;
        BasicBlockEdge BBE(all_edges[i]);
        for (int j=0; j<num_edges; j++) {
          if (i == j || elim[j]) continue;
          // If ith edge dominates the outgoing node of jth edge
          if (DT.dominates(BBE, all_edges[j].first)) {
            // jth edge is dominated (should be updated later than ith)
            dominated[j] = 1;
          }
        }
      }

      for (int i=0; i<num_edges; i++) {
        // Detect all edges that are not yet eliminated and not dominated by other edges
        if (!elim[i] && !dominated[i]) {
          edge_order->push_back(all_edges[i]);
          elim[i] = 1;
          --num_not_elim;
        }
      }
    }

    // Memory Cleaner
    all_edges.clear();
    elim.clear();
    dominated.clear();

    return edge_order;
  }

  // getTopologicalOrder - To make a safe order to propagate replacements.
  // Used to make an order of Value->Value replacements
  // Indegree-queuing algorithm has been used.
  vector<replacement>* getTopologicalOrder(map<Value*,set<Value*>> &edges) {
    vector<replacement> *edge_order = new vector<replacement>();

    map<Value*,int> indegree;
    set<Value*> nodes;

    for (auto &[X, SY] : edges) {
      nodes.insert(X);
      for (auto &Y : SY) {
        ++indegree[Y];
        nodes.insert(Y);
      }
    }

    queue<Value*> qu;
    for (auto &X : nodes) {
      // All starting nodes are zero indegrees.
      if (indegree[X] == 0)
        qu.push(X);
    }

    while (!qu.empty()) {
      Value *X = qu.front();
      qu.pop();
      set<Value*> &SY = edges[X];
      for (auto &Y : SY) {
        edge_order->emplace_back(X, Y);
        if (--indegree[Y] == 0 && STD_HAS_ELEMENT(edges, Y)) {
          qu.push(Y);
        }
      }
    }

    // Memory Cleaner
    indegree.clear();
    nodes.clear();
    return edge_order;
  }

  // replaceDominatedUses - Replace all uses that are dominated by the given BasicBlockEdge.
  // Replace Value *X into new Value *Y. (i.e., X <- Y)
  bool replaceDominatedUses(
    BasicBlockEdge &BBE, DominatorTree &DT,
    Value *X, Value *Y
  ) {
    vector<Use*> toReplace;
    for (auto &U : X->uses()) {
      if (DT.dominates(BBE, U)) {
        toReplace.push_back(&U);
      }
    }

    for (auto &Uptr : toReplace) {
      Uptr->set(Y);
    }

    bool updated = !toReplace.empty();
    toReplace.clear();
    return updated;
  }

  // propinteqOptimization - One iteration of propinteq optimization
  // Returns 1 if there is any update.
  bool propinteqOptimization(
    Function &F, DominatorTree &DT,
    map<BasicBlock*,map<Value*,int>> &instOrder,
    map<BasicBlock*,set<BasicBlock*>> &edges,
    map<pair<BasicBlock*,BasicBlock*>,map<Value*,set<Value*>>> &replacements
  ) {
    // Means that on `br T Z, X, Y' instruction on BasicBlock BB,
    // the replacements VtoR[Z] = (A, B) means that
    //   on for all blocks dominated by the edge (BB to X),
    //   the value replacement (A<-B) is valid.
    // Note that X is the truth block on the branch
    map<Value*,replacement> VtoR;

    // Detect all `icmp eq' instructions to find any possible replacements
    // The loop for `br' instructions is separated since detection is sequential.
    for (auto &BB : F) {
      for (auto &I : BB) {
        Value *X, *Y, *Z;
        ICmpInst::Predicate Pred;

        if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) &&
            Pred == ICmpInst::ICMP_EQ) {
          // If I is `icmp eq T X, Y'
          // outs() << X->getName() << ", " << Y->getName() << "\n";
          if (X == Y) continue; // No need to optimize

          int rep = getReplacementOrder(X, Y, instOrder, DT);
          if (rep == -1) continue;  // Cannot replace
          if (rep) swap(X, Y);      // The replacement X<-Y is valid

          VtoR[&I] = make_pair(X, Y);
        }
      }
    }

    // Detect all `br' instructions to find any possible replacements
    for (auto &BB : F) {
      for (auto &I : BB) {
        Value *X, *Y, *Z, *A, *B;
        if (match(&I, m_Br(m_Value(Z), m_Value(X), m_Value(Y)))) {
          // If I is `br T Z, label X, label Y'
          if (X == Y) continue; // Evil jump. (br targets for true and false are same)

          if (STD_HAS_ELEMENT(VtoR, Z)) { // Has a replacement
            BasicBlock *BX = dyn_cast<BasicBlock>(X);
            edges[&BB].insert(BX);
            tie(A, B) = VtoR[Z];
            replacements[{&BB, BX}][A].insert(B);
          }
        }
      }
    }

    bool updated = 0;
    vector<pair<BasicBlock*,BasicBlock*>> *update_order = getDominationOrder(DT, edges);

    // Fetch all BasicBlockEdge in the right order.
    for (auto &[Bfr, Bto] : *update_order) {
      BasicBlockEdge BBE(Bfr, Bto);
      auto &replaces = replacements[{Bfr, Bto}];
      vector<pair<Value*,Value*>> *replace_order = getTopologicalOrder(replaces);
      
      // Fetch all replacements in the right order.
      for (auto &[X, Y] : *replace_order) {
        updated |= replaceDominatedUses(BBE, DT, X, Y);
      }
      replace_order->clear();
    }

    // Memory cleaner
    VtoR.clear();
    update_order->clear();

    return updated;
  }


public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    map<BasicBlock*,map<Value*,int>> instOrder;
    for (auto &BB : F) {
      int instCnt = 0;
      for (auto &I : BB) {
        Value *X = &I;
        instOrder[&BB][X] = ++instCnt; // The instruction order
      }
    }

    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    map<BasicBlock*,set<BasicBlock*>> edges;

    // Means that in BasicBlock BB Value X should be replaced by the new Value Y
    map<pair<BasicBlock*,BasicBlock*>,map<Value*,set<Value*>>> replacements;

    // Do while there is any replacement.
    int max_iteration = 1e5; // To prevent an infinite loop
    while (max_iteration-- &&
           propinteqOptimization(F, DT, instOrder, edges, replacements));

    // Memory cleaner
    instOrder.clear();
    for (auto &[_, S] : edges) {
      S.clear();
    }
    edges.clear();
    for (auto &[_, rep] : replacements) {
      for (auto &[__, st] : rep) st.clear();
      rep.clear();
    }
    replacements.clear();

    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
