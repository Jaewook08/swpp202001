/* This code looks little bit long. Implementation seems right, 
   but it was hard to understand because of its length. In addition,
   there are some parts which can be replaced with faster ways. For
   example, std::set can be slower than std::unordered_set usually, 
   so using std::unordered_set or normal array can be faster. It is
   recommended to search related function with goal and apply to
   its complexity of code.
*/

#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/CFG.h"

#include <algorithm>
#include <set>
#include <queue>
#include "llvm/IR/PatternMatch.h"

using namespace llvm;
using namespace std;

using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {
public:
  void replaceAllYWithX(DominatorTree &DT, BasicBlock *dominatorBB, Value *X, Value *Y){
    // outs() << "replace starts\n"; //erase
    int cnt = 0;
    for (auto itr = Y->use_begin(), end = Y->use_end(); itr != end;) {
      // outs() << "inf loop " << cnt++ << "th?\n";//erase
      Use &U = *itr++;
      User *Usr = U.getUser();
      Instruction *UsrI = dyn_cast<Instruction>(Usr);
      if (UsrI) {
        BasicBlock *BB = UsrI->getParent();
        if (BB && DT.dominates(dominatorBB, BB)){
          U.set(X);
        }
      }
      if(cnt > 20) break;
    }
  }
  /* This function check whether first BasicBlock is predecessor
     of second BasicBlock or not. The time complexity of this
	 function is O(N log N), where N is the number of BasicBlock
	 in the dominator tree. However, this can be checked in O(1)
	 by doing topological sort at first. We can do topological
	 sort in O(N), so this would be better than below function.
  */
  bool firstIsPredecessorOfSecond(BasicBlock *First, BasicBlock *Second){
    std::queue<BasicBlock*> q;
    q.push(Second);

    std::set<BasicBlock*> predecessorBlocks;
    
    while(!q.empty()){
      BasicBlock *CurrBBPtr = q.front();
      q.pop();
      predecessorBlocks.insert(CurrBBPtr);
      for (BasicBlock *Pred : predecessors(CurrBBPtr)) {
        auto it = std::find(predecessorBlocks.begin(), predecessorBlocks.end(), Pred);
        if(it == predecessorBlocks.end()){
          //not in visited blocks
          q.push(Pred);
          predecessorBlocks.insert(Pred);
        }
      }
    }
    auto it2 = std::find(predecessorBlocks.begin(), predecessorBlocks.end(), First);
    return it2 == predecessorBlocks.end() ? false : true;


    // for (BasicBlock *Pred : predecessors(Second)) {
    //   if(Pred == First){
    //     return true;
    //   }
    // }
    // return false;
  }

  
  /* This function runs BFS in dominator Tree to find branch instruction, 
     which uses icmp value of checking integer equality. In details, this
	 function uses std::queue and std::set to implement BFS, and uses 
	 range-based for loop to traverse dominator tree. To develop this function
	 better, it seems to make adjacent list (or adjacent matrix) for dominator
	 tree with std::vector. This can splits the function into two parts: one 
	 is make adjacent list which represents domninator tree and another is 
	 traverse the dominator tree, and makes easier implementation.
	 
	 Also, this function uses std::set for checking BasicBlocks to visit.
	 However, std::set has O(log N) time complexity while inserting and
	 deleting, where N is the number of elements in the set. It seems better
	 to use std::unordered_set instead of std::set, because std::unordered_set
	 uses hashing to identify key and has only O(1) while inserting and deleting.
  */
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);
    std::queue<BasicBlock*> q;
    BasicBlock &BBEntry = F.getEntryBlock();
    BasicBlock *BBEntryPtr = &BBEntry;
    q.push(BBEntryPtr);

    std::set<BasicBlock*> notVisitedBlocks;
    for (BasicBlock &BB : F){
      notVisitedBlocks.insert(&BB);
    }
    notVisitedBlocks.erase(BBEntryPtr);

    //BFS
    while(!q.empty()){
      //1. check the condition and put BB in q
      // outs() << "------------------one cycle starts-------------\n"; //erase
      BasicBlock *CurrBBPtr = q.front();
      q.pop();

      // //erase below 4 lines
      // int predcnt = 0;
      // outs() << "predecessors of " << CurrBBPtr->getName() << " is : ";
      // for (BasicBlock *Pred : predecessors(CurrBBPtr)) {
      //   predcnt++;
      //   outs() << Pred->getName() << " "; //erase
      // }
      // outs() << " and num of predecessor is "<< predcnt<< "\n";

      for(auto &BB : F){
        if(DT.dominates(CurrBBPtr, &BB) && CurrBBPtr != &BB && notVisitedBlocks.find(&BB) != notVisitedBlocks.end()){
          q.push(&BB);
          notVisitedBlocks.erase(&BB);
        }
      }

      Value *X, *Y;
      ICmpInst::Predicate Pred;
      
      for(auto &I : *CurrBBPtr){
		// Below if statement can be simplified by using
		// m_Br(m_ICmp( ~~ ), ~~) as condition.
        if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) && Pred == ICmpInst::ICMP_EQ){
          //ICmp eq 연산이면 이걸 쓰는 br 연산을 찾는다
          BranchInst *TI = dyn_cast<BranchInst>(CurrBBPtr->getTerminator());
          //blocks dominated by "icmp eq X==Y" 
          BasicBlock *BBNext = TI->getSuccessor(0);
          BasicBlock *BBElse = TI->getSuccessor(1);

          if(firstIsPredecessorOfSecond(BBElse, BBNext)){
            //BBElse가 BBNext의 predecessor가 아닐 조건
            continue;
          }
          // outs() << TI->getSuccessor(0)->getName() << " " << TI->getSuccessor(1)->getName() << "\n";//erase
          
          if(DT.dominates(CurrBBPtr, BBNext)){
            auto *A1 = dyn_cast<Argument>(X);
            auto *A2 = dyn_cast<Argument>(Y);

            if (A1 == nullptr && A2 == nullptr){
              auto *Inst1 = dyn_cast<Instruction>(X);
              auto *Inst2 = dyn_cast<Instruction>(Y);
              if(DT.dominates(Inst1, Inst2)){
                //1. two instructions are compared
				// This function can be replaced with replaceUsesWithIf() function.
                replaceAllYWithX(DT, BBNext, X, Y);
              }
              else{
                replaceAllYWithX(DT, BBNext, Y, X);
              }
            }
            else if(A1 != nullptr && A2 != nullptr){
              //2. two arguments are compared
              if(A1->getArgNo() < A2->getArgNo())
                replaceAllYWithX(DT, BBNext, X, Y);
              else
                replaceAllYWithX(DT, BBNext, Y, X);
            }
            else{
              //3. an argument is compared with an instruction
              if(A2 == nullptr){
                replaceAllYWithX(DT, BBNext, X, Y);
              }
              else{
                replaceAllYWithX(DT, BBNext, Y, X);
              }
            }
          }
        }
      }  
    }
    
    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
