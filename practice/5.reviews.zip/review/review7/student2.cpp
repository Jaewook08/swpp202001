#include "llvm/IR/PassManager.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Dominators.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Analysis/OrderedInstructions.h"
#include <vector>
#include <string>
using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;
namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {
  void ReplaceValue(BasicBlock &BB, Value *V1, Value *V2) {
    for(auto &I : BB){
      auto OI = I.op_begin();
      auto OE = I.op_end();
      for (;OI != OE; ++OI){
        if(*OI==V1){
          *OI=V2;
        }
      }
    }

    return;
  }  
  int IsArgument(Value *V, Function &F){
    int cnt=0;
    for(Argument &Arg : F.args()){
      cnt++;
      if(&Arg == V){
        return cnt;
      }
    }
    return 0;
  }
public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {

    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);
    for (auto &BB : F) {
      int isnext=0;
      Value *X, *Y; 
      for (auto &I : BB) { 
        ICmpInst::Predicate Pred;
        if(isnext>0){
          isnext=0;
          BasicBlockEdge BBE(&BB,BB.getTerminator()->getSuccessor(0));
          for(auto &BB2 : F){
            if(BB2.getName() == BB.getTerminator()->getSuccessor(0)->getName()){             
              if(DT.dominates(BBE,&BB2)){ // change value!
            //outs() << "visited!" << "\n";
                int flag=1;
                int argX = IsArgument(X,F);
                int argY = IsArgument(Y,F);                    
                // set priority
                if(argX > 0 && argX==argY) break; // comparing same things
                if(argX > 0 && argY > 0){
                  if(argX>argY){ //argX changes to argY
                    ReplaceValue(BB2, X, Y);
                  }
                  else{
                    flag--;
                    ReplaceValue(BB2, Y, X);
                  }
                }
                else if(argX == 0){
                  if(argY == 0){// X and Y is instruction
                    Instruction *UsrIX;
                    Instruction *UsrIY;
                    for(auto &BB3 : F){
                      for(auto &I2 : BB3){
                        if(I2.getName()==X->getName()){
                          UsrIX=&I2;
                        }
                        else if(I2.getName()==Y->getName()){
                          UsrIY=&I2;
                        }
                      }
                    }
                    //outs() << UsrIX << "    " << UsrIY <<"\n";
                    OrderedInstructions OI(&DT);
                    if(OI.dominates(UsrIX, UsrIY)){
                      flag--;
                      ReplaceValue(BB2, Y, X);
                    }                       
                    else{
                      ReplaceValue(BB2, X, Y);
                    }
                  }
                  //argY is argument, so X changes to Y
                  ReplaceValue(BB2, X, Y);
                }
                else{//argX is argument, so Y changes to X
                  flag--;
                  ReplaceValue(BB2, Y, X);
                }
                for(auto &doubleBB : F){
                  if(DT.dominates(&BB2, &doubleBB)){
                    //outs() << BB2.getName() << "\t" << doubleBB.getName() << "\n";
                    //outs() << X->getName() << "\t" << Y-> getName() << "\n";
                    if(flag==1){
                      ReplaceValue(doubleBB, X, Y);
                    }
                    else{
                      ReplaceValue(doubleBB, Y, X);
                    }
                  }
                }
              }
            }
          }
          continue;
        }
        if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) &&
                   Pred == ICmpInst::ICMP_EQ) {
          //outs() << X->getName() << "\t" << Y->getName() << "\n";
          isnext++;        
          //outs() << "checkpoint" << "\n";
        }

      }
    }
    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
