#include <algorithm>
#include "llvm/IR/PassManager.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Dominators.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;
using namespace PatternMatch;

namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {
  bool replace(const DominatorTree &DT, const BasicBlockEdge &BBE, Value *OldVal, Value *NewVal) {
    // replaces uses of OldVal with NewVal
    // given the use is dominated by edge BBE (according to DT).
    // returns true if at least one replacement has taken place.
    // returns false otherwise
    bool ret = false;
    for (auto it = OldVal->use_begin(), end = OldVal->use_end(); it != end; ) {
      Use &U = *it++;
      User *Usr = U.getUser();
      if (Instruction *UsrI = dyn_cast<Instruction>(Usr)) {
        // before replacing, check if
        // this use of Y is dominated by the conditional branch
        if (DT.dominates(BBE, UsrI->getParent())) {
          U.set(NewVal);
          ret = true;
        }
        // in case of phi nodes,
        // check the predecessor block for dominance
        else if (PHINode *PI = dyn_cast<PHINode>(UsrI)) {
          BasicBlock *Predecessor = PI->getIncomingBlock(U);
          if (DT.dominates(BBE, Predecessor)) {
            U.set(NewVal);
            ret = true;
          }
        }
      }
    }
    return ret;
  }
public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);
    
    // repeat replacing until no values can be replaced.
    bool changes = true;
    while (changes) {
      changes = false;
      for (BasicBlock &BB : F) {
        // check if the last instruction of this block
        // is a branch instruction.
        if (BranchInst *I = dyn_cast<BranchInst>(BB.getTerminator())) {
          // check if this instruction is a conditional branch.
          if (I->isConditional()) {
            Value *Condition = I->getCondition();
            BasicBlock *SuccessorTrue = I->getSuccessor(0);
            if (Instruction *ConditionAssignment = dyn_cast<Instruction>(Condition)) {
              // check if this condition is an integer equality.
              Value *X, *Y;
              ICmpInst::Predicate Pred;
              if (match(ConditionAssignment, m_ICmp(Pred, m_Value(X), m_Value(Y)))
                      && Pred == ICmpInst::ICMP_EQ) {
                // edge for the branch taken when true
                BasicBlockEdge BBE(&BB, SuccessorTrue);
                // decide whether to replace X's with Y's or vice versa
                Instruction *Comparand1 = dyn_cast<Instruction>(X);
                Instruction *Comparand2 = dyn_cast<Instruction>(Y);
                if (Comparand1 && Comparand2) {
                  // X and Y are both instructions.
                  // either of two instructions must dominate the other
                  // let Comparand1 be the earlier one
                  if (DT.dominates(Comparand2, Comparand1))
                    std::swap(Comparand1, Comparand2);
                  // replace Comparand2 with Comparand1
                  changes |= replace(DT, BBE, Comparand2, Comparand1);
                }
                else if (Comparand1 || Comparand2) {
                  // Either one of X or Y is an instruction
                  // while the other is an argument.
                  // let Y point to the instruction
                  if (Comparand1)
                    std::swap(X, Y);
                  // replace Y's with X's
                  changes |= replace(DT, BBE, Y, X);
                }
                else {
                  // X and Y are both arguments.
                  Argument *Argument1 = dyn_cast<Argument>(X);
                  Argument *Argument2 = dyn_cast<Argument>(Y);
                  // let Argument1 be the earlier one
                  if (Argument1->getArgNo() > Argument2->getArgNo())
                    std::swap(Argument1, Argument2);
                  // replace Argument2 with Argument1
                  changes |= replace(DT, BBE, Argument2, Argument1);
                }
              }
            }
          }
        }
      }
    }
  return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
