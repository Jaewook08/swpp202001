#include "llvm/IR/PassManager.h"
#include "llvm/IR/ValueSymbolTable.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/PatternMatch.h"
#include<vector>
#include "bits/stdc++.h"

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {
public:
  void change(BasicBlock &BB, Value *from, Value *to){
    for (auto &II : BB)
      for (unsigned i = 0, E = II.getNumOperands(); i != E; ++i)
        if (II.getOperand(i) == from)
          II.setOperand(i, to);
  }
  BasicBlock* BLOK(Function &F,Value *V){
    for (BasicBlock &BB : F) 
      for (auto &I : BB) 
        if(((&I)->getName())==(V->getName()))
          return &BB;
    return NULL;
  }
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    map<string,int>id; int pos=0;//index of arguments in Function
    for(Function::arg_iterator args= F.arg_begin(); args!=F.arg_end(); args++){
      Value *X=args;
      id[X->getName().str()]=++pos;
    }
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);
    for (BasicBlock &ICM : F) {
      for (auto &I : ICM) {
        Value *X, *Y, *Z;
        ConstantInt *C;
        ICmpInst::Predicate Pred;
       if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) && Pred == ICmpInst::ICMP_EQ) {
            BasicBlock *BBTrue = ICM.getTerminator()->getSuccessor(0);
            BasicBlockEdge BBE(&ICM, BBTrue);
            for (BasicBlock &BB : F)
              if (DT.dominates(BBE, &BB)){
                  bool XY=false,YX=false;
                   BasicBlock *FX=BLOK(F,X),*FY=BLOK(F,Y);
                  //1st rule
                  if(FX!=NULL && FY!=NULL && FX!=FY){
                    if(DT.dominates(FX,FY))//If Block of X dominates the Block of Y
                      YX=true;
                    if(DT.dominates(FY,FX))//If Block of Y dominates the Block of X
                      XY=true;
                  }
                  //2nd rule
                  int XX=id[string(X->getName())], YY=id[string(Y->getName())];
                  if(XX && YY){
                    if(XX<YY)//If X appears in argument list before Y
                      YX=true;
                    else
                      XY=true;
                  }
                  //3rd rule
                  if(XX && !YY)//If X is argument and Y is Instruction
                    YX=true;
                  if(!XX && YY)//If Y is argument and X is Instruction
                    XY=true;
                  //4th rule
                  if(!XX && !YY && FX==FY){//Both of Instruction and in the same Block
                    int VX,VY,idx;
                    VX=VY=idx=0;
                    for (auto &IX : *FX){idx++;
                      if(((&IX)->getName())==(X->getName()))
                        VX=idx;
                      if(((&IX)->getName())==(Y->getName()))
                        VY=idx;
                    }
                    if(VX && VY){
                      if(VX<VY)
                        YX=true;
                      else
                        XY=true;
                    }
                  } 
                  //apply changes
                  if(YX)
                    change(BB,Y,X);
                  if(XY)
                    change(BB,X,Y);

              }
        }
        
      }
    }
    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
