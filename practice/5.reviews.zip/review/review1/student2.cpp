#include "llvm/IR/PassManager.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality
    : public PassInfoMixin<PropagateIntegerEquality> {

public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    // declare DominatorTree to use
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    for (auto &BB : F) {
      for (auto &I : BB) {
        Value *X, *Y;
        ICmpInst::Predicate Pred;
        // check all equality compare instructions
        if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) &&
            Pred == ICmpInst::ICMP_EQ) {
          Value *A = I.getOperand(0);
          Value *B = I.getOperand(1);
          bool aIsReplacedByb;
          auto *C1 = dyn_cast<Instruction>(A);
          auto *C2 = dyn_cast<Instruction>(B);
          auto *C3 = dyn_cast<Argument>(A);
          auto *C4 = dyn_cast<Argument>(B);

          // check if operands are not instruction nor argument
          if ((C1 == nullptr && C3 == nullptr) ||
              (C2 == nullptr && C4 == nullptr)) {
            continue;
          }

          // decide which one is replaced with another
          if (C1) {
            if (C2) {
              if (DT.dominates(C1, C2)) {
                aIsReplacedByb = false;
              } else {
                aIsReplacedByb = true;
              }
            } else {
              aIsReplacedByb = true;
            }
          } else {
            if (C2) {
              aIsReplacedByb = false;
            } else {
              StringRef aID = A->getName();
              StringRef bID = B->getName();
              for (size_t i = 0; i < F.arg_size(); ++i) {
                if (F.getArg(i)->getName() == aID) {
                  aIsReplacedByb = false;
                  break;
                } else if (F.getArg(i)->getName() == bID) {
                  aIsReplacedByb = true;
                  break;
                }
              }
            }
          }

          vector<BasicBlockEdge> allDependedTrueEdges;
          for (auto &BBB : F) {
            BranchInst *lastInst = dyn_cast<BranchInst>(BBB.getTerminator());
            if (!lastInst || lastInst->isUnconditional()) {
              continue;
            } else {
              if (DT.dominates(&I, lastInst) &&
                  lastInst->getCondition()->getName() == I.getName()) {
                BasicBlockEdge BBE(&BBB, lastInst->getSuccessor(0));
                // Edge between current BasicBlock and Successor with True
                // condition
                allDependedTrueEdges.push_back(BBE);
              }
            }
          }
          vector<Use *> replaceUses;
          // check all usage, replace one with another
          if (aIsReplacedByb) {
            for (Use &U : A->uses()) {
              for (BasicBlockEdge BBE : allDependedTrueEdges) {
                if (DT.dominates(BBE, U)) {
                  replaceUses.push_back(&U);
                  break;
                }
              }
            }
            for (Use *U : replaceUses) {
              U->set(B);
            }
          } else {
            for (Use &U : B->uses()) {
              for (BasicBlockEdge BBE : allDependedTrueEdges) {
                if (DT.dominates(BBE, U)) {
                  replaceUses.push_back(&U);
                  break;
                }
              }
            }
            for (Use *U : replaceUses) {
              U->set(A);
            }
          }
        }
      }
    }

    return PreservedAnalyses::all();
  }
};
} // namespace

extern "C" ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
          [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                  if (Name == "prop-int-eq") {
                    FPM.addPass(PropagateIntegerEquality());
                    return true;
                  }
                  return false;
                });
          }};
}
