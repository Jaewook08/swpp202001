// Correctness
// - Replacements should be applied in a dominance order. Otherwise, more
//   iterations are required. The dominance order may differ from the written
//   order on a code.
//   e.g. a->b dominates b->c(wrt. their true-edges), and b->c is applied
//   before a->b. Then the uses of 'a' dominated by the true-edge for b->c
//   are replaced with 'b', hence it still can be optimized.

#include "llvm/IR/PassManager.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality
    : public PassInfoMixin<PropagateIntegerEquality> {

public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    // declare DominatorTree to use
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    for (auto &BB : F) {
      for (auto &I : BB) {
        Value *X, *Y;
        ICmpInst::Predicate Pred;
        // check all equality compare instructions
        if (match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) &&
            Pred == ICmpInst::ICMP_EQ) {
          // Redundancy: A and B are already in X and Y
          Value *A = I.getOperand(0);
          Value *B = I.getOperand(1);
          bool aIsReplacedByb;
          // Suggest: How about more intuitive names?
          //          e.g. InstA or ArgB
          auto *C1 = dyn_cast<Instruction>(A);
          auto *C2 = dyn_cast<Instruction>(B);
          auto *C3 = dyn_cast<Argument>(A);
          auto *C4 = dyn_cast<Argument>(B);

          // check if operands are not instruction nor argument
          if ((C1 == nullptr && C3 == nullptr) ||
              (C2 == nullptr && C4 == nullptr)) {
            continue;
          }

          // decide which one is replaced with another
          // Suggest: This nested condition clause can be clearer.
          if (C1) {
            // for example, if (C2 && DT.dominates(C1, C2)) - else
            if (C2) {
              if (DT.dominates(C1, C2)) {
                aIsReplacedByb = false;
              } else {
                aIsReplacedByb = true;
              }
            } else {
              aIsReplacedByb = true;
            }
          } else {
            if (C2) {
              aIsReplacedByb = false;
            } else {
              // There is a function that returns the index of the argument.
              // C3->getArgNo() returns the index of A.
              StringRef aID = A->getName();
              StringRef bID = B->getName();
              for (size_t i = 0; i < F.arg_size(); ++i) {
                if (F.getArg(i)->getName() == aID) {
                  aIsReplacedByb = false;
                  break;
                } else if (F.getArg(i)->getName() == bID) {
                  aIsReplacedByb = true;
                  break;
                }
              }
            }
          }

          // The restriction of the assignment makes this redundant.
          // An instruction can be used as a condition of at most one branch
          // instruction.
          vector<BasicBlockEdge> allDependedTrueEdges;
          for (auto &BBB : F) {
            BranchInst *lastInst = dyn_cast<BranchInst>(BBB.getTerminator());
            if (!lastInst || lastInst->isUnconditional()) {
              continue;
            } else {
              // This can be written with 'else if'
              if (DT.dominates(&I, lastInst) &&
                  lastInst->getCondition()->getName() == I.getName()) {
                // Corectness: What if the both successors are the same?
                //             In case of phi node, this could be hazardous.
                BasicBlockEdge BBE(&BBB, lastInst->getSuccessor(0));
                // Edge between current BasicBlock and Successor with True
                // condition 
                allDependedTrueEdges.push_back(BBE);
              }
            }
          }
          vector<Use *> replaceUses;
          // check all usage, replace one with another
          // Suggest: You can swap A and B instead of writing the same code.
          if (aIsReplacedByb) {
            for (Use &U : A->uses()) {
              for (BasicBlockEdge BBE : allDependedTrueEdges) {
                if (DT.dominates(BBE, U)) {
                  replaceUses.push_back(&U);
                  break;
                }
              }
            }
            for (Use *U : replaceUses) {
              U->set(B);
            }
          } else {
            for (Use &U : B->uses()) {
              for (BasicBlockEdge BBE : allDependedTrueEdges) {
                if (DT.dominates(BBE, U)) {
                  replaceUses.push_back(&U);
                  break;
                }
              }
            }
            for (Use *U : replaceUses) {
              U->set(A);
            }
          }
        }
      }
    }

    return PreservedAnalyses::all();
  }
};
} // namespace

extern "C" ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
          [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                  if (Name == "prop-int-eq") {
                    FPM.addPass(PropagateIntegerEquality());
                    return true;
                  }
                  return false;
                });
          }};
}
