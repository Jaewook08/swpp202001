#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/PatternMatch.h"

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {
public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
	  DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);
	  for(auto &BB1 : F){
		  for(auto &I1 : BB1){
			  switch(I1.getOpcode()){
				  case Instruction::ICmp:{
					bool eq=false;
					if(dyn_cast<ICmpInst>(&I1)!=nullptr) eq=dyn_cast<ICmpInst>(&I1)->getPredicate()==CmpInst::ICMP_EQ;
					if(!eq) continue;
					BasicBlock *BX,*BY;
					 Value *V1 = I1.getOperand(0);
					 Value *V2 = I1.getOperand(1);
					 Value *lvalue = &cast<Value>(I1);
					 if(dyn_cast<Argument>(V1)!=nullptr && dyn_cast<Argument>(V2)==nullptr){
						 //Case 1
					 }
					 else if (dyn_cast<Argument>(V1)==nullptr && dyn_cast<Argument>(V2)!=nullptr){
						 //Case 2
						 Value *T = V1;
						 V1 = V2;
						 V2 = T;
					 }
					 else if (dyn_cast<Argument>(V1)!=nullptr && dyn_cast<Argument>(V2)!=nullptr){
						 if(dyn_cast<Argument>(V1) -> getArgNo() >  dyn_cast<Argument>(V2) -> getArgNo()){
					//		 Case 3
							 Value *T = V1;
							 V1 = V2;
							 V2 = T;
						 }
					 }
					 else{
						 //Case 4
						 //find V1, V2
						 bool flag=false;
						 for(auto &TB : F){
							 if(flag) break;
							 for(auto &TI : TB){
								 if(flag) break;
								 if(&cast<Value>(TI) == V1){
									 flag=true;
									 break;
								 }
								 else if(&cast<Value>(TI) == V2){
									 Value *T = V1;
									 V1=V2;
									 V2=T;
									 flag=true;
									 break;
								 }
							 }
						 }
					 }
					 for(auto &I2 : BB1){
						 if(match(&I2,m_Br(m_Value(lvalue),m_BasicBlock(BX),m_BasicBlock(BY)))){
							 BasicBlock *BBB=BY;
							 if(eq) BBB=BX;
							 BasicBlockEdge BBE(&BB1,BBB);
							 for(auto itr = V2->use_begin(),end=V2->use_end();itr!=end;){
								 Use &U = *itr++;
								 User *Usr = U.getUser();
								 Instruction *UsrI = dyn_cast<Instruction>(Usr);
								 if(UsrI){
									 BasicBlock *BB = UsrI->getParent();
									 if(DT.dominates(BBE,BB)) U.set(V1);
								 }
							 }
						 }
					 }
				}
			  	default:{
					break;
				  }
			  }
		  }
	  }
	  return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
