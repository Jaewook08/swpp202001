/* [Overall] Code Review Comments
 *
 * [Expected danger 1] This code uses the domination between BasicBlockEdge
 *   and 'BasicBlock'(Not 'Use'). It might cause a scoping error on phi
 *   instruction inside '[]'.
 *     E.g., on "phi i32 [%b, %bb_true], [%b, %bb_false]" the scope of [%b,
 *   %bb_true] is on the block %bb_true, but not on the block the phi
 *   instruction is located. It should replace %b->%a inside the first []
 *   when %bb_true is dominated by the truth branch of "icmp eq i32 %a, %b",
 *   but this code does not catch it.
 *
 * [Expected danger 2] This code only fetches instructions in a sequential
 *   order. It is problematic on an LLVM code that goes in a reversed order on
 *   the run-time. E.g., for the following LLVM code,
 *     define i32 @f(i32 %a, i32 %b, i32 %c) {
 *         br label %bb_entry
 *       bb_true2:
 *         call i32 @f(i32 %a, i32 %b, i32 %c)  ; ******
 *         ret i32 0
 *       bb_true:
 *         br (icmp eq i32 %b, %c), label %bb_true2, label %bb_exit
 *       bb_entry:
 *         br (icmp eq i32 %a, %c), label %bb_true, label %bb_exit
 *       bb_exit:
 *         ret i32 0
 *     }
 *   The asterisk part(******) should be optimized by '@f(%a, %a, %a)' but
 *   this code outputs '@f(%a, %b, %b)'.
 */
#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/PatternMatch.h"
#include <iostream>

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {

    void replaceSpecificUses(Value *V, Value *Change, BasicBlock *BBcompare) {

    for (auto itr = V->use_begin(), end = V->use_end(); itr != end;) {
      Use &U = *itr++;
      User *Usr = U.getUser();
      Instruction *UsrI = dyn_cast<Instruction>(Usr);
      if (UsrI) {
        BasicBlock *BB = UsrI->getParent();
        /* [Suggestion] "if (BB == BBcompare)" is simpler. */
        if (BB->getName() == BBcompare->getName())
          U.set(Change);
      }
    }
  }

public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    //go through basic block in function f
    for( auto &BB : F){

      //go through instructions at the basic block
      for( auto &I : BB){

        //look for icmp eq instruction
        Value *X, *Y;
        ICmpInst::Predicate Pred;

        if(match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) && Pred == ICmpInst::ICMP_EQ){
          
          //check if they are not constants
          auto *C1 = dyn_cast<ConstantInt>(X);
          auto *C2 = dyn_cast<ConstantInt>(Y);
          /* [Logical Issue] Isn't it "if (C1 == nullptr && C2 == nullptr)"? */
          // TA: Negate the condition and put continue, instead of having one
          //   more indentation
          // TA: if (isa<Constant>(X) || isa<Constant>(Y)) continue;
          //   undef is not ConstantInt.
          if (C1 == nullptr || C2 == nullptr){//both of them are not constants

            BasicBlock &BBhere = BB;
            BranchInst *TI = dyn_cast<BranchInst>(BBhere.getTerminator());
            BasicBlock *BBNext = TI->getSuccessor(0);
            /* [Logical Issue] I think it must check whether
             *   'TI->getSuccessor(0) != TI->getSuccessor(1)', since there might
             *   be an evil branch like: "br i1 %cond, label %bb, label %bb". It
             *   should not optimize on %bb block */
            BasicBlockEdge BBE(&BBhere, BBNext);

            //find a block that is dominated by edge BBE.
            for (BasicBlock &BB : F) {

              //if dominated, change Y 
              if (DT.dominates(BBE, &BB)) {

                //check for arguments
                auto *arg1 = dyn_cast<Argument>(X);
                auto *arg2 = dyn_cast<Argument>(Y);

                if((arg1 != nullptr) && (arg2 != nullptr)){
                  /* [Suggestion] "if (arg1 < arg2)" is okay. */
                  // TA: The result of arg1 < arg2 is dependent on its
                  // implementation detail. Using ArgNo is better.
                  if(arg1->getArgNo() < arg2->getArgNo()){
                    replaceSpecificUses(Y,X,&BB);
                  }else{
                    replaceSpecificUses(X,Y,&BB);
                  }
                }else if(arg1 != nullptr){
                  replaceSpecificUses(Y,X,&BB);
                }else if(arg2 != nullptr){
                  replaceSpecificUses(X,Y,&BB);
                }else{

                  //now X and Y are not arguments. Check for domanance of instructions
                  //look for the first usage of values, which are the definitions
				  /* [Suggestion] I think
				   *   Instruction *I1
				   *     = dyn_cast<Instruction>(*(X->use_begin()));
				   *   is much simpler. */
                  auto itr1 = X->use_begin();
                  auto itr2 = Y->use_begin();
                  Use &U1 = *itr1;
                  Use &U2 = *itr2;

                  Instruction *I1 = dyn_cast<Instruction>(U1);
                  Instruction *I2 = dyn_cast<Instruction>(U2);

                  if(DT.dominates(I1,I2)){
                    replaceSpecificUses(Y,X,&BB);
                  }else{
                    replaceSpecificUses(X,Y,&BB);
                  }
                  
                }
              }
            }

          }
          //X or Y is constant
        }
        //instruction is not icmp
      }
    }
    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
