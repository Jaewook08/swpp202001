#include "llvm/IR/PassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/PatternMatch.h"
#include <iostream>

using namespace llvm;
using namespace std;
using namespace llvm::PatternMatch;

namespace {
class PropagateIntegerEquality : public PassInfoMixin<PropagateIntegerEquality> {

    void replaceSpecificUses(Value *V, Value *Change, BasicBlock *BBcompare) {
    
    for (auto itr = V->use_begin(), end = V->use_end(); itr != end;) {
      Use &U = *itr++;
      User *Usr = U.getUser();
      Instruction *UsrI = dyn_cast<Instruction>(Usr);
      if (UsrI) {
        BasicBlock *BB = UsrI->getParent();
        if (BB->getName() == BBcompare->getName())
          U.set(Change);
      }
    }
  }

public:
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &FAM) {
    
    DominatorTree &DT = FAM.getResult<DominatorTreeAnalysis>(F);

    //go through basic block in function f
    for( auto &BB : F){

      //go through instructions at the basic block
      for( auto &I : BB){

        //look for icmp eq instruction
        Value *X, *Y;
        ICmpInst::Predicate Pred;

        if(match(&I, m_ICmp(Pred, m_Value(X), m_Value(Y))) && Pred == ICmpInst::ICMP_EQ){
          
          //check if they are not constants
          auto *C1 = dyn_cast<ConstantInt>(X);
          auto *C2 = dyn_cast<ConstantInt>(Y);
          if (C1 == nullptr || C2 == nullptr){//both of them are not constants

            BasicBlock &BBhere = BB;
            BranchInst *TI = dyn_cast<BranchInst>(BBhere.getTerminator());
            BasicBlock *BBNext = TI->getSuccessor(0);
            BasicBlockEdge BBE(&BBhere, BBNext);

            //find a block that is dominated by edge BBE.
            for (BasicBlock &BB : F) {

              //if dominated, change Y 
              if (DT.dominates(BBE, &BB)) {

                //check for arguments
                auto *arg1 = dyn_cast<Argument>(X);
                auto *arg2 = dyn_cast<Argument>(Y);

                if((arg1 != nullptr) && (arg2 != nullptr)){
                  if(arg1->getArgNo() < arg2->getArgNo()){
                    replaceSpecificUses(Y,X,&BB);
                  }else{
                    replaceSpecificUses(X,Y,&BB);
                  }
                }else if(arg1 != nullptr){
                  replaceSpecificUses(Y,X,&BB);
                }else if(arg2 != nullptr){
                  replaceSpecificUses(X,Y,&BB);
                }else{

                  //now X and Y are not arguments. Check for domanance of instructions
                  //look for the first usage of values, which are the definitions
                  auto itr1 = X->use_begin();
                  auto itr2 = Y->use_begin();
                  Use &U1 = *itr1;
                  Use &U2 = *itr2;

                  Instruction *I1 = dyn_cast<Instruction>(U1);
                  Instruction *I2 = dyn_cast<Instruction>(U2);

                  if(DT.dominates(I1,I2)){
                    replaceSpecificUses(Y,X,&BB);
                  }else{
                    replaceSpecificUses(X,Y,&BB);
                  }
                  
                }
              }
            }

          }
          //X or Y is constant
        }
        //instruction is not icmp
      }
    }
    return PreservedAnalyses::all();
  }
};
}

extern "C" ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "PropagateIntegerEquality", "v0.1",
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
           ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "prop-int-eq") {
            FPM.addPass(PropagateIntegerEquality());
            return true;
          }
          return false;
        }
      );
    }
  };
}
